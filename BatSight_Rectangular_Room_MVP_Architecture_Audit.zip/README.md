# BatSight

BatSight is a research-oriented acoustic room reconstruction project. The first working release is prioritized around rectangular shoebox rooms; this is a delivery focus, not a permanent restriction. The broader general convex-polyhedral research mode and its historical artifacts remain preserved. The current checkout provides signal processing and forward synthetic tools, but no production inverse room reconstruction estimator.

## Scientific scope

The primary reference is Crocco, Trucco, and Del Bue, “Uncalibrated 3D Room Reconstruction from Sound” (arXiv:1606.06258, 2016). The paper's setting uses multiple microphones, multiple known emissions, and estimates microphone positions, source positions, emission times, clock offsets, and planar room boundaries jointly. It assumes a convex polyhedron with known face count and known emitted signal. A single laptop microphone recording can support chirp playback/recording experiments, waveform and spectrogram inspection, and exploratory echo/TOA analysis; it is not sufficient evidence or an assumed input for reproducing the paper's complete uncalibrated 3D reconstruction.

## Current architecture and status

- `src/batsight/signals/`: implemented typed audio/time models, generic test waveforms, mono matched filtering, and peak detection. Generic sweeps do not claim to reproduce the unresolved paper chirp.
- `src/batsight/simulation/shoebox.py`: implemented axis-aligned shoebox image-source/RIR simulator through second order; forward only.
- `src/batsight/datasets/toa.py`: implemented synthetic direct-path TOA generation with timing offsets, noise, missingness, and JSON serialization; forward only.
- `src/batsight/experiments/pipeline.py`: implemented forward simulation-to-peak comparison and CSV/report data.
- `src/batsight/geometry/` and `src/batsight/optimization/`: package placeholders only; no production geometry estimator or optimizer.
- `backend/` and `frontend/`: planning boundaries only; no FastAPI or React application.
- `experiments/exploratory/`: preserved Phase 5C research scripts and records; these are not production APIs.

See the [rectangular-room MVP architecture audit](docs/rectangular_room_mvp_architecture.md), [validation plan](docs/rectangular_room_validation_plan.md), and [reconstruction modes](docs/reconstruction_modes.md). The existing general convex-room paper research remains linked below.

## Research audit and roadmap

- [Research specification](docs/research_spec.md)
- [Assumptions and limitations](docs/assumptions_and_limitations.md)
- [Implementation plan](docs/implementation_plan.md)
- [Validation plan](docs/validation_plan.md)
- [Signal-processing conventions and limitations](docs/signal_processing.md)
- [Synthetic shoebox simulation conventions](docs/room_simulation.md)
- [Synthetic experiment orchestration and metrics](docs/experiments.md)
- [Uncalibrated direct-path TOA observation model](docs/uncalibrated_toa_model.md)
- [Initial localization derivation and equation crosswalk](docs/initial_localization_derivation.md)
- [Initial localization open questions](docs/initial_localization_open_questions.md)
- [Reference-derived initial localization design](docs/reference_derived_localization_design.md)
- [Initial localization validation matrix](docs/localization_validation_matrix.md)
- [Initial localization implementation status](docs/initial_localization_implementation.md)
- [Blind initialization failure analysis (Phase 5C.14)](docs/blind_initialization_failure_analysis.md)
- [Timing and coordinate block analysis (Phase 5C.15)](docs/timing_coordinate_block_analysis.md)
- [Local convergence basin analysis (Phase 5C.16)](docs/local_convergence_basin_analysis.md)
- [Direct-path initialization recovery (Phase 5C.17)](docs/direct_path_initialization_recovery.md)
- [Direct-path identifiability study (Phase 5C.18)](docs/direct_path_identifiability_study.md)
- [Rectangular-room MVP architecture audit](docs/rectangular_room_mvp_architecture.md)
- [Rectangular-room validation plan](docs/rectangular_room_validation_plan.md)
- [Reconstruction modes](docs/reconstruction_modes.md)

The supplied 2016 preprint is archived in `research/Uncalibrated_3D_Room_Reconstruction_from_Sound.pdf`; its record is [arXiv:1606.06258](https://arxiv.org/abs/1606.06258). The related 2017 journal article is separately documented in `docs/research_spec.md`. Its full text was not available from the publisher/repository sources checked, so the preprint and journal article remain distinct references and a complete version reconciliation remains open.

## Status

Phase 2A provides typed signal models, generic engineering waveform generation, reference-based matched filtering, and threshold peak detection. Phase 2B adds a forward-only shoebox image-source simulator. Phase 3 connects these components into reproducible synthetic experiments and TOA comparison reports. Phase 4 adds a forward-only, sampling-independent synthetic dataset for direct-path TOAs with known source and microphone positions, independent emission times and clock offsets, optional timing noise, and missing observations. Phase 5A documented the cited initialization mathematics; Phase 5B specifies a reference-derived general-offset timing and coordinate-recovery design plus a synthetic validation matrix. Phase 5C remains blocked because the paper-derived timing stage has not met recovery criteria. Phase 5C.4 found that three tested positive-TOA rank-only alternatives failed the Crocco metric residual gate, while the generating truth passed on both determinant branches; this finite search does not prove global uniqueness. Phase 5C.5 demonstrated local direct-TOA recovery from truth and nearby perturbations. Phase 5C.6 found a deterministic zero-timing plus cross-distance SVD/Crocco start that repeatedly recovered the seed-11 solution, but noisy minimum-count trials failed and a Gaubitch-derived start reached a distinct machine-precision fit. This remains an exploratory initializer, not a production method or a paper-reproduction claim. Phase 5C.7 independently tested unknown convex-room feasibility, ideal first-order reflection observations, and deterministic count/placement variants against the archived seed-11 competing endpoint. An arbitrary unknown convex enclosure does not disambiguate finite coordinate sets; the reflection check could not be fairly blind-fit without latent wall estimation; added observations changed conditioning and outcomes but did not produce consistent recovery. Phase 5C.8 unknown-wall results were invalidated as an inverse-model test by a source-plane dot-product bug in its predicted image-source calculation; its historical files remain preserved. Phase 5C.9 independently verified the corrected predictor at oracle walls, recovered those walls from deterministic perturbations, and found one blind PCA recovery for the generating endpoint. Phase 5C.10 tested 19 data-derived PCA/offset starts, explicit scaling, assignment-aware blocks and penalty continuation for the competitor. Some candidates pass every geometry check but have large echo residuals; high-penalty fits become severely ill-conditioned. The generating PCA regression still passes, but the competing endpoint remains unresolved and no disambiguation or uniqueness claim is justified. Phase 5C.11 jointly fit direct TOAs, unlabeled first-order echoes, timing, coordinates, and six walls. Phase 5C.12 verified an analytic echo Jacobian away from association ties and measured local recovery through 1e-3 scaled-coordinate perturbations on the seed-11 fixture. PCA starts contain echo-order ties; analytic derivatives improved, but did not eliminate, their non-exact fits. The competing endpoint remains unresolved, and these finite experiments do not establish uniqueness. These are exploratory synthetic results, not global uniqueness evidence. Phase 5C remains blocked. No production inverse localization engine or wall estimator has been delivered. No phase claims exact reproduction of the unresolved 2016 equations or complete paper experiment. No application UI or measured BatSight reconstruction results are included.

Phase 5C.13 investigated balanced entropic transport for unlabeled first-order echoes. Its derivative checks passed at tested checkpoints, but the fixed continuation failed numerically on extreme optimizer trial costs. Smooth-only solutions were biased; smooth-plus-hard refinement recovered the generating PCA case but not the competing PCA case, so the method is not accepted. The competing endpoint remains unresolved. See the Phase 5C.13 report and full exploratory results.

Phase 5C.13 artifacts: [research report](docs/initial_localization_implementation.md), [exploratory solver](experiments/exploratory/phase5c13_smooth_echo_assignment.py), [full results and parameter vectors](experiments/exploratory/phase5c13_results.json), and [run log](experiments/exploratory/phase5c13_run.log).

Phase 5C.14 traced the exact archived C11 blind starts through direct TOA fitting, conditional timing, PCA/wall-only fitting, exact sorted joint refinement, and a frozen-association ablation. The earliest divergence is already the direct-path seed (0.053–0.076 s direct residual; 3.34–3.81 m aligned position RMSE). Direct-only fitting reduced residuals to 4.96e-5–2.06e-4 s without recovering geometry, and all three exact-sorted joint outcomes remained non-exact. This supports a coupled initialization/basin problem under the tested settings; it does not prove a unique cause or infeasibility. See the [Phase 5C.14 analysis](docs/blind_initialization_failure_analysis.md), [runner](experiments/exploratory/phase5c14_blind_initialization.py), [results](experiments/exploratory/phase5c14_results.json), and [run log](experiments/exploratory/phase5c14_run.log).

Phase 5C.15 profiled timing-only, coordinate-only, and alternating blocks on the exact C11 blind vectors, with the staged generating solution as a positive control. Conditional timing reduced objective but worsened timing error under fixed wrong geometry. Coordinate-only optimization improved position RMSE to 1.73–2.44 m. Eight alternating cycles reduced objective by 84.6–92.5%, yet retained 2.93–3.21 m position RMSE and millisecond-scale timing errors. The positive control stayed at machine precision. These exploratory results do not establish a production initializer. See the [Phase 5C.15 analysis](docs/timing_coordinate_block_analysis.md), [script](experiments/exploratory/phase5c15_block_profiling.py), [full results](experiments/exploratory/phase5c15_results.json), and [run log](experiments/exploratory/phase5c15_run.log).

Phase 5C.16 mapped the local basin from the exact staged reference using 36 deterministic oracle-centered perturbations across microphone, source, timing, wall, and combined parameter blocks. Joint recovery passed both tested directions through scaled magnitude 0.05 for every isolated group; at 0.4 it remained successful for microphone perturbations, failed for source and combined perturbations, and passed one of two wall directions. Pure timing perturbations were recovered through 0.4 by timing-only and joint fits. Alternating timing/coordinate updates did not recover geometry perturbations within the four-cycle budget. These finite local results do not imply blind recovery or a universal basin radius. See the [Phase 5C.16 report](docs/local_convergence_basin_analysis.md), [script](experiments/exploratory/phase5c16_basin_mapping.py), [results](experiments/exploratory/phase5c16_results.json), and [run log](experiments/exploratory/phase5c16_run.log).


Phase 5C.17 compared existing TOA-only initializers across six deterministic synthetic cases. No raw blind start met the strict geometry/timing screen before refinement. Refinement recovered none of the minimum-count noiseless cases; a Gaubitch-derived timing plus Crocco fit recovered one larger diverse noiseless case, and direct multistart recovered two of five there. Measurement-fit passes often retained incorrect geometry/timing, especially in below-count and noisy clustered cases. No initializer is accepted. See [Phase 5C.17 analysis](docs/direct_path_initialization_recovery.md), [runner](experiments/exploratory/phase5c17_direct_initialization.py), [results](experiments/exploratory/phase5c17_results.json), and [run log](experiments/exploratory/phase5c17_run.log).





Phase 5C.18 ran a matched-seed OAT study across 12 configurations and eight starts per method. The gauge-fixed truth Jacobian was rank deficient for below-count and planar cells; several below-count and baseline fits yielded substantially different aligned geometries at near-zero residual. Recovery depended on configuration and start, and no initializer generalized across all factors. A full-rank local Jacobian did not rule out competing fits. No production method was accepted. See [report](docs/direct_path_identifiability_study.md), [runner](experiments/exploratory/phase5c18_identifiability.py), [results](experiments/exploratory/phase5c18_results.json), and [run log](experiments/exploratory/phase5c18_run.log).




## Rectangular-room MVP direction

The first release will prioritize constrained shoebox reconstruction while retaining general convex-polyhedral research as a distinct future mode. This is not an assertion that rectangular constraints resolve the current localization ambiguity: direct-path TOAs contain no room-dimension term, and Phase 5C.18 found start-dependent recovery and near-exact competing geometries. Before implementation, BatSight must select the calibration/unknown-variable profile and identify what independent reflection or boundary observations constrain the box. A single stationary laptop microphone remains a signal-analysis demonstration, not the full multichannel 3D reconstruction mode. No inverse estimator has been approved or implemented.
