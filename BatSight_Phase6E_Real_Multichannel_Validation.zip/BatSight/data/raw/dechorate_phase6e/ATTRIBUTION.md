# dEchorate Phase 6E sample

This folder contains a small subset of the dEchorate dataset used by the BatSight Phase 6E validation experiment:

- `dEchorate_room000000_src1_arr1_mics1-5.sofa` (1,758,263 bytes)
- `dEchorate_annotations.h5` (30,324 bytes)

The SOFA file embeds an MIT license statement in its global `License` attribute. The annotation HDF5 is from the dEchorate Zenodo record, whose record metadata declares CC BY 4.0. The sample was copied from the public SOFA database mirror; see [the database index](https://sofacoustics.org/data/database/dechorate/) and [Zenodo record 6576203](https://zenodo.org/records/6576203). Cite Di Carlo et al., “dEchorate: a calibrated room impulse response dataset for echo-aware signal processing,” DOI [10.1186/s13636-021-00229-0](https://doi.org/10.1186/s13636-021-00229-0).

Only this small RIR subset and the compact annotation file are included. The 25.8 GB Zenodo archive was not downloaded. These files are unmodified source data; do not attribute them to BatSight.
