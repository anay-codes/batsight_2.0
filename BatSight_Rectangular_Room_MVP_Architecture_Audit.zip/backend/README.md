# Backend boundary

Reserved for a future FastAPI application and request/response schemas. Keep the Python reconstruction engine in `src/batsight/`; the backend should call stable engine interfaces rather than embed signal or geometry algorithms. No API or server implementation is included in Phase 1.
