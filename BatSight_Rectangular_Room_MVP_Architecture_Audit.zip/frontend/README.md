# Frontend boundary

Reserved for a future React + TypeScript client. Planned views separate single-laptop signal exploration from multichannel research experiments. No UI or package dependencies are included in Phase 1.
